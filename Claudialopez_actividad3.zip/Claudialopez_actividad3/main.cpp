#include <iostream>
#include <string>
using namespace std;
int main()
{

cout << "Introduce tu apellido paterno: ";
string paterno;
cin >> paterno;

cout << "Introduce tu apellido materno: ";
string materno;
cin >> materno;

cout << "Introduce tu nombre: ";
string nombre;
cin >> nombre;

cout << "Introduce tu fecha de nacimiento (sólo números): ";
cout << "Día: ";
string dia;
cin >> dia;

cout << "Mes: ";
string mes;
cin >> mes;

cout << "Año: ";
string ano;
cin >> ano;

cout << "Tu RFC sin homoclave es: " << paterno.substr(0,2) << materno.substr(0,1)
<< nombre.substr(0,1) << ano.substr(2,3) << mes.substr(0,2) << "XXX" << endl;

return 0;

}